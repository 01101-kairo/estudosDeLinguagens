public class Conta {
	private int cadastro;
	private String titular;
	private double saldo;


	public Conta(int cadastro, String titular, double initDeposito){
		this.cadastro = cadastro;
		this.titular = titular;
		operacao(initDeposito);
	}

	public void operacao(double resultado) {
		saldo = saldo + resultado;
	}

	public void operacao(double resultado, double taxa) {
		saldo = saldo - (resultado + taxa);
	}

	public void account() {
		System.out.println("Account: "+ cadastro
				+ "\nHolder:"+ titular
				+ "\nBalance: $ "+ String.format("%.2f", saldo));
	}
}
