import java.util.Scanner;
public class Banco {

	public static void main(String[] args) {
		double taxa=5.00;
		Scanner scan = new Scanner(System.in);
		Conta banco;

		System.out.print("Enter account number:");
		int cadastro = scan.nextInt();

		System.out.print("Enter account holder:");
		String titular = scan.next();

		System.out.print("\nIs there na initial deposit(y/n)?");
		char depositar = scan.next().charAt(0);

		if (depositar == 'y'){
			System.out.print("Enter initial deposit value:");
			double initDeposito = scan.nextDouble();
			banco = new Conta(cadastro, titular, initDeposito);
			banco.account();

		}else{
			banco = new Conta(cadastro, titular, 0.00);
			banco.account();
		}

		System.out.print("Enter a deposit value:");
		double deposito = scan.nextDouble();
		banco.operacao(deposito);
		System.out.println("Updated account data: ");
		banco.account();

		System.out.print("Enter a withdraw value:");
		double saque = scan.nextDouble();
		banco.operacao(saque, taxa);
		System.out.println("\nUpdated account data:");
		banco.account();
	}
}
