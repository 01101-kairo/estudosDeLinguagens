import java.util.Scanner;
public class Account {
	private int cadastro;
	private String titular;
	private double saldo;

	public Account(int cadastro, String titular, double initdeposit){
		this.cadastro = cadastro;
		this.titular = titular;
		getdeposit(initdeposit);
	}
	public void Account() {
		System.out.println(
				"Account: "+ cadastro
				+ ", Holder:"+ titular
				+ ", Balance: $ "+ String.format("%.2f", saldo));
	}

	public void getdeposit(double deposit) {
		saldo=saldo+deposit;
	}
	public void getwithdraw(double withdraw) {
		saldo=saldo-(withdraw+5.0);
	}


	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		Account Account;

		System.out.print("Enter account number::");
		int cadastro = scan.nextInt();

		System.out.print("Enter account holder:");
		String titular = scan.next();

		System.out.print("Is there na initial deposit(y/n)?");
		char depositar = scan.next().charAt(0);

		if (depositar == 'y'){
			System.out.print("Enter initial deposit value:");
			double initdeposit = scan.nextDouble();
			Account = new Account(cadastro, titular, initdeposit);
			Account.Account();

		}else{
			Account = new Account(cadastro, titular, 0.00);
			Account.Account();
		}
		System.out.print("deposit:");
		double deposit = scan.nextDouble();
		Account.getdeposit(deposit);
		System.out.print("Conta data: ");
		Account.Account();

		System.out.print("withdraw:");
		double withdraw = scan.nextDouble();
		Account.getwithdraw(withdraw);
		System.out.print("Conta data: ");
		Account.Account();
	}
}
