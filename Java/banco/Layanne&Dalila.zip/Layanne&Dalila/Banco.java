import javax.swing.JOptionPane;
public class Banco {
	private int cadastro;
	private String titular;
	private double saldo;

	public Banco(int cadastro, String titular, double initDeposito){
		this.cadastro = cadastro;
		this.titular = titular;
		deposito(initDeposito);
	}

	public void deposito(double resultado) {
		saldo += resultado;
	}

	public void saque(double resultado) {
		saldo -= resultado + 5.0;
	}

	public void getConta() {
		JOptionPane.showMessageDialog(null,"Updated account data:\n"
				+"Conta: "+ cadastro
				+ ", Titular:"+ titular
				+ ", Saldo: $ "+ String.format("%.2f", saldo));
	}
	public static void main(String[] args) {
		Banco banco;

		int cadastro = Integer.parseInt(JOptionPane.showInputDialog(null,"Enter account number:"));

		String titular = JOptionPane.showInputDialog(null,"Enter account holder:");

int reply = JOptionPane.showConfirmDialog(null,"\nIs there na initial deposit","info", JOptionPane.YES_NO_OPTION);
  if (reply == JOptionPane.YES_OPTION){

			double initDeposito = Double.parseDouble(JOptionPane.showInputDialog(null,"\nEnter initial deposit value:"));
			banco = new Banco(cadastro, titular, initDeposito);
			banco.getConta();

		}else{
			banco = new Banco(cadastro, titular, 0.00);
			banco.getConta();
		}

		double deposito = Double.parseDouble(JOptionPane.showInputDialog(null,"\nEnter a deposit value:"));
		banco.deposito(deposito);
		banco.getConta();

		double saque = Double.parseDouble(JOptionPane.showInputDialog(null,"\nEnter a withdraw value:"));
		banco.saque(saque);
		banco.getConta();
	}
}
