import java.util.Scanner;
public class account {
	private int number;
	private String titular;
	private double saldo;

	public account(int number, String titular, double init_deposit){
		this.number = number;
		this.titular = titular;
		deposit(init_deposit);
	}
	public account(int number, String titular){
		this.number = number;
		this.titular = titular;
	}
	public void account(){
		System.out.println("Conta: "+ number
				+ ", Titular:"+ titular
				+ ", Saldo: $ "+ String.format("%.2f", saldo));
	}

	public void deposit(double resultado) {
		saldo += resultado;
	}

	public void withdraw(double resultado) {
		saldo -= resultado + 5.0;
	}


	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		account banco;

		System.out.print("Enter account number:");
		int number = scan.nextInt();

		System.out.print("Enter account holder:");
		String titular = scan.next();

		System.out.print("\nIs there na initial deposit (y/n)?");
		char depositar = scan.next().charAt(0);

		if (depositar == 'y'){
			System.out.println("Enter initial deposit value:");
			double initdeposit = scan.nextDouble();
			banco = new account(number, titular, initdeposit);
			banco.account();

		}else{
			banco = new account(number, titular);
			banco.account();
		}

		System.out.print("Enter a deposit value:");
		double deposit = scan.nextDouble();
		banco.deposit(deposit);
		System.out.print("Account data: ");
		banco.account();

		System.out.print("Enter a withdraw value:");
		double withdraw = scan.nextDouble();
		banco.withdraw(withdraw);
		System.out.print("Account data: ");
		banco.account();
	}
}
